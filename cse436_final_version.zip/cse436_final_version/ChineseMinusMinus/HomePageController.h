//
//  ViewController.h
//  ChineseMinusMinus
//
//  Created by Azure Hu on 4/2/15.
//  Copyright (c) 2015 Azure Hu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomePageController : UIViewController

@property (weak, nonatomic) IBOutlet UIWebView *caligraphy;

@end

