//
//  ScoreBoardController.h
//  ChineseMinusMinus
//
//  Created by Labuser on 4/11/15.
//  Copyright (c) 2015 Azure Hu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScoreBoardController : UIViewController

@end
