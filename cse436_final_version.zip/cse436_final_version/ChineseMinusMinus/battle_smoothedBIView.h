//
//  battle_smoothedBIView.h
//  ChineseMinusMinus
//
//  Created by Azure Hu on 4/17/15.
//  Copyright (c) 2015 Azure Hu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface battle_smoothedBIView : UIView

@end
