//
//  Battle_InfoControllerViewController.h
//  ChineseMinusMinus
//
//  Created by Azure Hu on 4/18/15.
//  Copyright (c) 2015 Azure Hu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BattleController.h"

@interface Battle_InfoControllerViewController : UIViewController


@end
