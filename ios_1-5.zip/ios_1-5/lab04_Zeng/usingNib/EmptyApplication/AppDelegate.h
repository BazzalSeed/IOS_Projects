//
//  AppDelegate.h
//  EmptyApplication
//
//  Created by Todd Sproull on 2/8/15.
//  Copyright (c) 2015 StudentName. All rights reserved.
//

#import <UIKit/UIKit.h>
#import"tabbar_ViewController1.h"
#import"tabbar_ViewController2.h"
#import"tabbar_ViewController3.h"
#import "detailedview_ViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
