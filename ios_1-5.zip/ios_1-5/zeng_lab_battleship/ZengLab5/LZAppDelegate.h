//
//  LZAppDelegate.h
//  ZengLab5
//
//  Created by Peiyun Zeng on 3/29/15.
//  Copyright (c) 2015 LZ. All rights reserved.

#import <UIKit/UIKit.h>
#import "LZGameViewController.h"

@interface LZAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
