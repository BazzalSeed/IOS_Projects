Simple-iOS-Battleship-Game-
===========================

iOS Lab for course #436 in WUSTL. Only spent 3 days..so don't take it so serious..
