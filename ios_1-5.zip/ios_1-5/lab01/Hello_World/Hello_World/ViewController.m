//
//  ViewController.m
//  Hello_World
//
//  Created by Peiyun Zeng on 1/21/15.
//  Copyright (c) 2015 Peiyun Zeng. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end



@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)button:(id)sender {
//    self.ano
}
- (IBAction)slider:(id)sender {
}
- (IBAction)pressedButton:(id)sender {
    NSLog(@"In button");
    

}

@end
