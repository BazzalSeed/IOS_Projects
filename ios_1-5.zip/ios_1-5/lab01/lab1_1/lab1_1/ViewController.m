//
//  ViewController.m
//  lab1_1
//
//  Created by Peiyun Zeng on 1/21/15.
//  Copyright (c) 2015 Peiyun Zeng. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *dd;

@end





@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)button:(id)sender {
    NSLog(@"%d",counter);
    if (counter ==0){
    self.image0.hidden= NO;
    self.image1.hidden= YES;
    self.image2.hidden= YES;
    self.image3.hidden= YES;
        counter++;}
   /*
    }
    else if(counter==1){
        self.image0.hidden= YES;
        self.image1.hidden= NO;
        self.image2.hidden= YES;
        self.image3.hidden= YES;
         counter++;
    }
    else if(counter==2){
        self.image0.hidden= YES;
        self.image1.hidden= YES;
        self.image2.hidden= NO;
        self.image3.hidden= YES;
         counter++;
    
    }
    
    else if(counter==3){
        self.image0.hidden= YES;
        self.image1.hidden= YES;
        self.image2.hidden= YES;
        self.image3.hidden= NO;
        counter =0;
        
    }
    */
    
}
- (IBAction)slider:(id)sender {
    float Value;
    Value = self.sliderinfo.value;
    self.image0.alpha = Value*0.01;
    self.image1.alpha = Value*0.01;
    self.image2.alpha = Value*0.01;
    self.image3.alpha = Value*0.01;
    
    
    
}

@end
