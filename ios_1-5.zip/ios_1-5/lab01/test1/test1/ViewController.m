//
//  ViewController.m
//  test1
//
//  Created by Peiyun Zeng on 1/21/15.
//  Copyright (c) 2015 Peiyun Zeng. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)buttonPressed:(id)sender {
    
    self.theImage.hi
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
