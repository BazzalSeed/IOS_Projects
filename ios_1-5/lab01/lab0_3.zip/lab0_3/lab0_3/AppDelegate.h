//
//  AppDelegate.h
//  lab0_3
//
//  Created by Peiyun Zeng on 1/23/15.
//  Copyright (c) 2015 Peiyun Zeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

